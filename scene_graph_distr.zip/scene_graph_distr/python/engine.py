class Engine:
  def Update (self, dt):
    pass