class Interpolator:
  def Interpolate (self, t):
    pass
