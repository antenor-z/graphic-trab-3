class Shape:
  pass