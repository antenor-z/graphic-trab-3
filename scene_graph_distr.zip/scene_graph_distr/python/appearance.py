class Appearance:
  def Unload (self, st):
    pass